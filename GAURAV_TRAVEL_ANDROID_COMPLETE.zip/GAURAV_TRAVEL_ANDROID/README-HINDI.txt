GAURAV TRAVEL - ANDROID APK PROJECT

ऐप: GAURAV TRAVEL
Call: 9129069898
WhatsApp Booking: +91 7007346876

इस प्रोजेक्ट में Android WebView ऐप और ग्राहक बुकिंग पेज शामिल है। ग्राहक वाहन चुनकर विवरण भरता है और Book Now दबाने पर WhatsApp में पूरी बुकिंग जानकारी तैयार होती है। ग्राहक को WhatsApp में Send दबाना होगा।

APK बनाने का तरीका:
1. इस ZIP को Extract करें।
2. Extract किए गए फोल्डर के अंदर की सभी फाइलें और फोल्डर GitHub repository के root में अपलोड करें। ZIP को GitHub पर सीधे upload न करें।
3. GitHub repository में Actions खोलें।
4. Build GAURAV TRAVEL APK workflow चुनें। यदि push से workflow अपने आप न चले तो Run workflow दबाएँ।
5. Build सफल होने पर workflow run के नीचे Artifacts में GAURAV-TRAVEL-APK डाउनलोड करें।
6. ZIP artifact को Extract करें और app-debug.apk खोलकर Install करें।

ध्यान दें:
- यह source project है, पहले से compiled APK नहीं। APK GitHub Actions पर build होगी।
- वाहन तस्वीरें third-party URLs से लोड होती हैं; इनके लिए इंटरनेट चाहिए और वेबसाइटें URL/hotlink बदल सकती हैं।
- बुकिंग WhatsApp पर तभी पहुँचेगी जब ग्राहक WhatsApp में Send दबाएगा।
- यह ऐप secure owner/admin backend या online payment प्रदान नहीं करता।
